# Gauntlt

## Prereqs
Arachni, the tool gauntlt calls to run appsec attacks, cannot scan localhost or 127.X.X.X.  To get around this, add `127.0.0.1 wordcloud` to /etc/hosts (will need sudo access)

## Find out more
Go to gauntlt.org for more info.
